# Copyright (c) OpenMMLab. All rights reserved.
from .max_3d_iou_assigner import Max3DIoUAssigner

__all__ = ['Max3DIoUAssigner']
